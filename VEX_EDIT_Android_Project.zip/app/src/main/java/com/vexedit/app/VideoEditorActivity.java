package com.vexedit.app;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.EditedMediaItem;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.Locale;

public class VideoEditorActivity extends AppCompatActivity {
    private Uri inputUri;
    private ExoPlayer player;
    private long durationMs = 0;
    private EditText startEdit, endEdit;
    private TextView durationText, hintText;
    private ProgressBar progressBar;
    private Button exportButton;
    private Transformer transformer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private File outputTempFile;
    private boolean exporting = false;

    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_editor);

        inputUri = getIntent().getData();
        if (inputUri == null) {
            finish();
            return;
        }

        PlayerView playerView = findViewById(R.id.playerView);
        startEdit = findViewById(R.id.editStart);
        endEdit = findViewById(R.id.editEnd);
        durationText = findViewById(R.id.txtDuration);
        hintText = findViewById(R.id.txtHint);
        progressBar = findViewById(R.id.progress);
        exportButton = findViewById(R.id.btnExport);

        readDuration();
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(inputUri));
        player.prepare();
        player.setPlayWhenReady(false);

        exportButton.setOnClickListener(v -> startExport());
    }

    private void readDuration() {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, inputUri);
            String value = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            durationMs = value == null ? 0 : Long.parseLong(value);
            endEdit.setText(String.format(Locale.US, "%.2f", durationMs / 1000.0));
            durationText.setText("Duration: " + formatTime(durationMs));
        } catch (Exception e) {
            hintText.setText("Could not read video duration: " + e.getMessage());
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
    }

    private void startExport() {
        if (exporting) return;
        long startMs, endMs;
        try {
            startMs = (long) (Double.parseDouble(startEdit.getText().toString().trim()) * 1000);
            endMs = (long) (Double.parseDouble(endEdit.getText().toString().trim()) * 1000);
        } catch (Exception e) {
            toast("Enter valid start and end times.");
            return;
        }

        if (durationMs <= 0 || startMs < 0 || endMs <= startMs || endMs > durationMs) {
            toast("Invalid range. End must be after start and within the video.");
            return;
        }

        exporting = true;
        exportButton.setEnabled(false);
        progressBar.setVisibility(android.view.View.VISIBLE);
        progressBar.setIndeterminate(true);
        hintText.setText("Preparing video export...");

        outputTempFile = new File(getCacheDir(), "vex_export_" + System.currentTimeMillis() + ".mp4");
        MediaItem.ClippingConfiguration clipping = new MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build();
        MediaItem clippedItem = new MediaItem.Builder()
            .setUri(inputUri)
            .setClippingConfiguration(clipping)
            .build();
        EditedMediaItem editedItem = new EditedMediaItem.Builder(clippedItem).build();

        transformer = new Transformer.Builder(this)
            .addListener(new Transformer.Listener() {
                @Override public void onCompleted(Composition composition, ExportResult result) {
                    exporting = false;
                    progressBar.setIndeterminate(false);
                    progressBar.setProgress(100);
                    saveToGallery(outputTempFile);
                }

                @Override public void onError(Composition composition, ExportResult result, ExportException exception) {
                    exporting = false;
                    resetExportButton();
                    hintText.setText("Export failed: " + exception.getMessage());
                    toast("Export failed. Try another video format.");
                    if (outputTempFile != null) outputTempFile.delete();
                }
            })
            .build();

        transformer.start(editedItem, outputTempFile.getAbsolutePath());
        pollProgress();
    }

    private void pollProgress() {
        if (!exporting || transformer == null) return;
        ProgressHolder holder = new ProgressHolder();
        int state = transformer.getProgress(holder);
        if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
            progressBar.setIndeterminate(false);
            progressBar.setProgress(holder.progress);
            hintText.setText("Exporting... " + holder.progress + "%");
        }
        handler.postDelayed(this::pollProgress, 300);
    }

    private void saveToGallery(File source) {
        if (source == null || !source.exists()) {
            resetExportButton();
            toast("Export file was not created.");
            return;
        }

        String fileName = "VEX_EDIT_" + System.currentTimeMillis() + ".mp4";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VEX EDIT");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);

        Uri collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri savedUri = null;
        try {
            savedUri = getContentResolver().insert(collection, values);
            if (savedUri == null) throw new IOException("Could not create gallery entry");
            try (InputStream in = new FileInputStream(source);
                 OutputStream out = getContentResolver().openOutputStream(savedUri, "w")) {
                if (out == null) throw new IOException("Could not open output stream");
                byte[] buffer = new byte[1024 * 64];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                out.flush();
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.Video.Media.IS_PENDING, 0);
            getContentResolver().update(savedUri, ready, null, null);
            hintText.setText("Saved to Movies/VEX EDIT");
            toast("Video exported successfully!");
        } catch (Exception e) {
            if (savedUri != null) getContentResolver().delete(savedUri, null, null);
            hintText.setText("Could not save video: " + e.getMessage());
            toast("Could not save video.");
        } finally {
            source.delete();
            resetExportButton();
        }
    }

    private void resetExportButton() {
        exportButton.setEnabled(true);
        progressBar.setVisibility(android.view.View.GONE);
        exportButton.setText("Export trimmed video");
    }

    private String formatTime(long ms) {
        long seconds = ms / 1000;
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
