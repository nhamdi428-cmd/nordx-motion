package com.vexedit.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private ActivityResultLauncher<PickVisualMediaRequest> videoPicker;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        videoPicker = registerForActivityResult(
            new ActivityResultContracts.PickVisualMedia(), this::openSelectedVideo);

        Button importButton = findViewById(R.id.btnImport);
        importButton.setOnClickListener(v -> {
            videoPicker.launch(new PickVisualMediaRequest.Builder()
                .setMediaType(ActivityResultContracts.PickVisualMedia.VideoOnly.INSTANCE)
                .build());
        });
    }

    private void openSelectedVideo(Uri uri) {
        if (uri == null) {
            Toast.makeText(this, "No video selected", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(this, VideoEditorActivity.class);
        intent.setData(uri);
        startActivity(intent);
    }
}
