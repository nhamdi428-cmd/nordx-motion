# VEX EDIT — الإصدار الأول

مشروع Android أولي بلغة Java وواجهات XML.

## الوظائف الموجودة
- اختيار فيديو عبر Android Photo Picker دون طلب صلاحية قراءة عامة للمعرض.
- معاينة الفيديو باستخدام Media3 ExoPlayer.
- تحديد بداية ونهاية القص بالثواني.
- قص فعلي باستخدام Media3 Transformer.
- نسخ ملف MP4 الناتج إلى Movies/VEX EDIT عبر MediaStore.

## البناء
1. افتح المشروع في بيئة Android Gradle تدعم Android Gradle Plugin 8.7.3 وJava 17.
2. اسمح بتنزيل المكتبات من Google Maven وMaven Central.
3. نفّذ Gradle Sync ثم Build APK.

## ملاحظات
- Media3 Transformer يستخدم ترميز الجهاز؛ قد تختلف السرعة والامتدادات المدعومة حسب الهاتف.
- النسخة الأولى تعتمد على حقلي وقت البداية والنهاية بدلاً من مقابض timeline مرئية.
- لا توجد صلاحيات تخزين عامة في Manifest؛ Photo Picker يمنح التطبيق وصولاً للعنصر الذي اختاره المستخدم.
- لا يتضمن المشروع Gradle Wrapper، لذا افتحه في بيئة توفر Gradle/Android build tools.
- يلزم اختبار المشروع فعلياً على جهاز Android قبل اعتباره إصداراً نهائياً.
